#define BLYNK_TEMPLATE_ID "YOUR_BLYNK_TEMPLATE_ID"
#define BLYNK_TEMPLATE_NAME "YOUR_BLYNK_TEMPLATE_NAME"
#define BLYNK_AUTH_TOKEN "YOUR_BLYNK_AUTH_TOKEN"

#include <WiFi.h>
#include <BlynkSimpleEsp32.h>
#include <DHT.h>
#include <Wire.h>
#include <Adafruit_GFX.h>
#include <Adafruit_SSD1306.h>

char ssid[] = "YOUR_WIFI_NAME";
char pass[] = "YOUR_WIFI_PASSWORD";

#define DHT_PIN 4
#define DHT_TYPE DHT22
#define SOIL1_PIN 35
#define SOIL2_PIN 32
#define LDR_PIN 34
#define WATER_PIN 27
#define RELAY_PUMP_PIN 26
#define RELAY_FAN_PIN 14
#define RELAY_LIGHT_PIN 25
#define BUZZER_PIN 33

// Set true only if your relay module turns ON when its input is LOW.
const bool RELAY_ACTIVE_LOW = true;

// Calibrate these raw ADC values for your sensors.
const int SOIL1_DRY_ADC = 3000;
const int SOIL1_WET_ADC = 1300;
const int SOIL2_DRY_ADC = 3000;
const int SOIL2_WET_ADC = 1300;
const int SOIL_DRY_THRESHOLD = 35;       // percent
const float FAN_ON_TEMP_C = 28.0;
const int LIGHT_ON_ADC_THRESHOLD = 1200;  // calibrate for your LDR module
const int WATER_AVAILABLE_LEVEL = LOW;   // change after testing sensor polarity

#define SCREEN_WIDTH 128
#define SCREEN_HEIGHT 64
Adafruit_SSD1306 display(SCREEN_WIDTH, SCREEN_HEIGHT, &Wire, -1);
DHT dht(DHT_PIN, DHT_TYPE);
BlynkTimer timer;

int moisturePercent(int raw, int dryAdc, int wetAdc) {
  if (dryAdc == wetAdc) return 0;
  long value = map(raw, dryAdc, wetAdc, 0, 100);
  return constrain((int)value, 0, 100);
}

void setRelay(int pin, bool on) {
  digitalWrite(pin, RELAY_ACTIVE_LOW ? (on ? LOW : HIGH) : (on ? HIGH : LOW));
}

void updateSystem() {
  float temperature = dht.readTemperature();
  float humidity = dht.readHumidity();
  int soil1Raw = analogRead(SOIL1_PIN);
  int soil2Raw = analogRead(SOIL2_PIN);
  int ldrRaw = analogRead(LDR_PIN);
  bool waterAvailable = (digitalRead(WATER_PIN) == WATER_AVAILABLE_LEVEL);

  int soil1 = moisturePercent(soil1Raw, SOIL1_DRY_ADC, SOIL1_WET_ADC);
  int soil2 = moisturePercent(soil2Raw, SOIL2_DRY_ADC, SOIL2_WET_ADC);

  // Fail-safe: invalid DHT readings do not trigger temperature-based actions.
  bool fanOn = !isnan(temperature) && temperature >= FAN_ON_TEMP_C;
  bool pumpOn = waterAvailable && (soil1 < SOIL_DRY_THRESHOLD || soil2 < SOIL_DRY_THRESHOLD);
  bool lightOn = (ldrRaw < LIGHT_ON_ADC_THRESHOLD);

  setRelay(RELAY_PUMP_PIN, pumpOn);
  setRelay(RELAY_FAN_PIN, fanOn);
  setRelay(RELAY_LIGHT_PIN, lightOn);

  if (!waterAvailable) {
    digitalWrite(BUZZER_PIN, HIGH);
  } else {
    digitalWrite(BUZZER_PIN, LOW);
  }

  Serial.printf("Temp: %.1f C, Humidity: %.1f%%, Soil1: %d%%, Soil2: %d%%, LDR: %d, Water: %s, Pump: %d, Fan: %d, Light: %d\n",
    temperature, humidity, soil1, soil2, ldrRaw, waterAvailable ? "available" : "low",
    pumpOn, fanOn, lightOn);

  if (display.width() > 0) {
    display.clearDisplay();
    display.setTextSize(1);
    display.setTextColor(SSD1306_WHITE);
    display.setCursor(0, 0);
    display.println("SmartGrow");
    if (isnan(temperature) || isnan(humidity)) {
      display.println("DHT read error");
    } else {
      display.printf("Temp: %.1f C\n", temperature);
      display.printf("Humidity: %.1f%%\n", humidity);
    }
    display.printf("Soil 1: %d%% Soil 2: %d%%\n", soil1, soil2);
    display.printf("Water: %s\n", waterAvailable ? "OK" : "LOW");
    display.printf("P:%d F:%d L:%d\n", pumpOn, fanOn, lightOn);
    display.display();
  }

  if (Blynk.connected()) {
    if (!isnan(temperature)) Blynk.virtualWrite(V0, temperature);
    if (!isnan(humidity)) Blynk.virtualWrite(V1, humidity);
    Blynk.virtualWrite(V2, soil1);
    Blynk.virtualWrite(V3, soil2);
    Blynk.virtualWrite(V4, ldrRaw);
    Blynk.virtualWrite(V5, waterAvailable ? 1 : 0);
    Blynk.virtualWrite(V6, pumpOn ? 1 : 0);
    Blynk.virtualWrite(V7, fanOn ? 1 : 0);
    Blynk.virtualWrite(V8, lightOn ? 1 : 0);
  }
}

void setup() {
  Serial.begin(115200);
  analogReadResolution(12);

  pinMode(WATER_PIN, INPUT_PULLUP);
  pinMode(RELAY_PUMP_PIN, OUTPUT);
  pinMode(RELAY_FAN_PIN, OUTPUT);
  pinMode(RELAY_LIGHT_PIN, OUTPUT);
  pinMode(BUZZER_PIN, OUTPUT);

  // Start in OFF state.
  setRelay(RELAY_PUMP_PIN, false);
  setRelay(RELAY_FAN_PIN, false);
  setRelay(RELAY_LIGHT_PIN, false);
  digitalWrite(BUZZER_PIN, LOW);

  dht.begin();
  Wire.begin(21, 22);
  if (display.begin(SSD1306_SWITCHCAPVCC, 0x3C)) {
    display.clearDisplay();
    display.setTextSize(1);
    display.setTextColor(SSD1306_WHITE);
    display.setCursor(0, 0);
    display.println("SmartGrow starting");
    display.display();
  } else {
    Serial.println("OLED not detected; check address/wiring.");
  }

  Blynk.begin(BLYNK_AUTH_TOKEN, ssid, pass);
  timer.setInterval(2000L, updateSystem);
}

void loop() {
  Blynk.run();
  timer.run();
}
