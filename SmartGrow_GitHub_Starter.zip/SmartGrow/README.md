# SmartGrow: ESP32-Based IoT Greenhouse Monitoring and Automation

SmartGrow is a prototype for monitoring a small greenhouse and automating irrigation, ventilation, and grow lighting. The starter firmware targets an ESP32, DHT22, two capacitive soil-moisture sensors, an LDR, a water-level input, a 3-channel relay module, SSD1306 OLED, buzzer, and Blynk IoT.

> **Status:** Starter implementation. Calibrate sensors and verify every pin and relay polarity on your own hardware before connecting pumps, fans, or mains-powered equipment. Sample data is illustrative, not measured project results.

## Features
- Temperature and relative-humidity readings from DHT22
- Two soil-moisture analog readings
- LDR analog reading
- Water-level digital input
- Automatic pump, fan, and grow-light control
- OLED status display and Blynk virtual-pin telemetry
- Serial diagnostics

## Repository layout
- `firmware/SmartGrow.ino` — ESP32 firmware
- `docs/architecture.md` — system architecture and data flow
- `docs/setup-guide.md` — wiring, libraries, configuration, and upload steps
- `docs/wiring-diagram.md` — pin map (verify against your actual circuit)
- `data/sample_sensor_data.csv` — illustrative sample data
- `tests/test_cases.md` — manual functional test plan
- `LICENSE` — MIT License

## Quick start
1. Install Arduino IDE and the ESP32 board support package.
2. Install the `DHT sensor library` by Adafruit, `Adafruit Unified Sensor`, `Adafruit SSD1306`, `Adafruit GFX Library`, and `Blynk` libraries.
3. Open `firmware/SmartGrow.ino`.
4. Replace `YOUR_BLYNK_TEMPLATE_ID`, `YOUR_BLYNK_TEMPLATE_NAME`, `YOUR_BLYNK_AUTH_TOKEN`, `YOUR_WIFI_NAME`, and `YOUR_WIFI_PASSWORD`.
5. Confirm the pin map and calibrate sensor values in the firmware.
6. Select your ESP32 board and port, compile, then upload.
7. Open Serial Monitor at 115200 baud and verify sensor values before enabling actuators.

## Blynk virtual pins
- V0: temperature (°C)
- V1: humidity (%)
- V2: soil sensor 1 (%)
- V3: soil sensor 2 (%)
- V4: light ADC reading
- V5: water available (0/1)
- V6: pump state (0/1)
- V7: fan state (0/1)
- V8: grow-light state (0/1)

Create matching datastreams in your Blynk template. This firmware reports telemetry; add dashboard widgets in Blynk Console/mobile app.

## Important safety and calibration notes
- ESP32 GPIO is **3.3 V only**. Do not feed 5 V signals into ESP32 pins.
- Do not power a pump or fan directly from an ESP32 GPIO.
- Confirm whether your relay board is active-low or active-high before use. The default below is active-low.
- Use suitable driver/relay ratings, flyback protection where required, insulated wiring, and a properly rated supply.
- The analog moisture and LDR percentages/thresholds depend on your particular sensors and installation. Calibrate dry/wet and dark/bright readings.
- The water-level input logic depends on your sensor module. Verify the safe state before relying on it to prevent dry running.
- This is a learning prototype, not a certified agricultural or safety controller.

## License
Released under the MIT License. See `LICENSE`.

## Contributions
Issues and pull requests are welcome. Please include board details, wiring changes, calibration values, and test evidence.
