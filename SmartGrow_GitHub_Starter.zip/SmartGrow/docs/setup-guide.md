# Setup Guide

## Hardware list
- ESP32 development board
- DHT22 temperature/humidity sensor
- Two capacitive soil-moisture sensors
- LDR module with analog output
- Water-level sensor with a compatible digital output
- 3-channel relay module compatible with ESP32 logic
- DC pump, ventilation fan, and grow light with suitable power supplies
- 0.96-inch SSD1306 I2C OLED (address commonly `0x3C`)
- Buzzer, breadboard, jumper wires, greenhouse prototype

## Pin map
See `wiring-diagram.md`. Check the exact pin labels on your board. GPIO 34, 35, and 32 are ADC-capable on common ESP32 DevKit boards; ADC behavior varies by board.

## Arduino IDE
1. Install Arduino IDE.
2. Add ESP32 board support using Espressif's official Arduino-ESP32 instructions: https://docs.espressif.com/projects/arduino-esp32/en/latest/installing.html
3. Install these libraries through Library Manager:
   - Blynk
   - DHT sensor library (Adafruit)
   - Adafruit Unified Sensor
   - Adafruit SSD1306
   - Adafruit GFX Library
4. Open `firmware/SmartGrow.ino`.
5. Replace all placeholder Blynk and Wi-Fi credentials in the sketch. Do not commit real credentials to a public repository.
6. Select the correct ESP32 board and serial port.
7. Compile and upload.
8. Open Serial Monitor at 115200 baud.

## Calibration
- Record raw ADC values for each soil sensor in dry soil and well-watered soil. Update `SOIL1_DRY_ADC`, `SOIL1_WET_ADC`, `SOIL2_DRY_ADC`, and `SOIL2_WET_ADC`.
- Record LDR readings in bright and dim conditions and adjust the light threshold.
- Test the water sensor and update `WATER_AVAILABLE_LEVEL` if its output polarity differs.
- Confirm relay ON/OFF polarity with actuators disconnected first.

## Blynk setup
Create a Blynk template and device. Add datastreams V0–V8 as listed in the root README, then copy the template ID, template name, and device auth token into the sketch. Keep tokens private.

## Troubleshooting
- `NaN` temperature/humidity: check DHT22 wiring, sensor type, power, and library.
- OLED blank: verify SDA/SCL pins, I2C address, and display wiring.
- Moisture stuck at 0/100%: recalibrate ADC dry/wet values and confirm the sensor is powered correctly.
- Relay behaves backward: verify active-low/active-high configuration.
- Blynk offline: verify credentials, Wi-Fi availability, and matching template datastreams.
