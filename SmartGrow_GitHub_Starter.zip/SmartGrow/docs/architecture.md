# SmartGrow Architecture

## Overview
SmartGrow follows a sensor–controller–actuator architecture. Sensors provide environmental readings to the ESP32. Firmware filters basic invalid readings, compares readings with configured thresholds, updates actuators, and publishes telemetry to Blynk. An OLED provides local status.

## Data flow
1. DHT22 measures temperature and relative humidity.
2. Two capacitive moisture sensors and an LDR provide analog readings.
3. The water-level sensor provides a digital input.
4. ESP32 converts analog readings to approximate percentages using calibration constants.
5. Control rules decide whether to run the pump, fan, and grow light.
6. OLED, Serial Monitor, and Blynk show readings and actuator states.

## Control rules in the starter firmware
- Pump: on when either soil-moisture percentage is below `SOIL_DRY_THRESHOLD` and water is available.
- Fan: on when temperature is at or above `FAN_ON_TEMP_C`.
- Grow light: on when the LDR reading is below `LIGHT_ON_ADC_THRESHOLD`.
- Pump is forced off if water is unavailable.

These are initial example rules, not agronomic recommendations. Tune them after measuring your sensors and crop conditions. A hysteresis/debounce strategy is recommended before long-term deployment.

## Reliability considerations
- Add sensor-disconnect detection and a safe actuator state.
- Calibrate each sensor individually.
- Consider hysteresis to prevent relay chatter.
- Add watchdog/reconnect handling for Wi-Fi and Blynk.
- Keep low-voltage electronics separate from mains wiring.
