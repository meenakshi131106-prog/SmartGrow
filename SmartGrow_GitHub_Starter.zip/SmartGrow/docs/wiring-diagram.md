# Wiring / Pin Reference

This is a suggested mapping for a common ESP32 DevKit. Confirm against your physical board and existing wiring before powering the system.

| Component | ESP32 pin | Notes |
|---|---:|---|
| DHT22 data | GPIO 4 | Use correct pull-up arrangement for your module |
| OLED SDA | GPIO 21 | I2C |
| OLED SCL | GPIO 22 | I2C |
| Soil moisture 1 analog | GPIO 35 | ADC input only |
| Soil moisture 2 analog | GPIO 32 | ADC input |
| LDR analog output | GPIO 34 | ADC input only |
| Water-level digital output | GPIO 27 | Firmware uses `INPUT_PULLUP`; adapt to sensor |
| Relay: pump | GPIO 26 | Confirm relay polarity |
| Relay: fan | GPIO 14 | Confirm relay polarity |
| Relay: grow light | GPIO 25 | Confirm relay polarity |
| Buzzer | GPIO 33 | Use a suitable driver if needed |

## Electrical cautions
- Share ground between low-voltage sensor modules and ESP32 where required.
- Never apply 5 V to an ESP32 GPIO.
- Check the relay module input compatibility and active level.
- Use separate, appropriately rated supplies for actuators; do not power motors from the ESP32 board.
- Keep high-voltage wiring out of breadboards and seek qualified supervision.
