# SmartGrow Test Cases

These are manual tests for the prototype. Record actual outcomes and evidence before claiming tests passed.

| ID | Test | Procedure | Expected result |
|---|---|---|---|
| TC-01 | DHT22 reading | Power on and observe Serial/OLED | Plausible temperature and humidity; no persistent NaN |
| TC-02 | Soil calibration | Compare raw values in dry and wet soil | Displayed moisture changes in expected direction |
| TC-03 | Irrigation starts | Set calibrated moisture below threshold with water available | Pump relay activates |
| TC-04 | Dry-run protection | Set water sensor to low-water state while soil is dry | Pump remains OFF; buzzer indicates low water |
| TC-05 | Fan control | Raise sensed temperature above configured threshold | Fan relay activates |
| TC-06 | Grow light | Reduce LDR reading below configured threshold | Grow-light relay activates |
| TC-07 | OLED | Start with display connected at configured I2C address | Status and readings appear |
| TC-08 | Blynk telemetry | Connect Wi-Fi and valid Blynk device | V0–V8 datastreams update |
| TC-09 | Relay polarity | Test with actuators disconnected | ON/OFF states match intended logic |
| TC-10 | Restart behavior | Restart controller | All relays start in OFF state before normal control loop |

## Test record template
For each test, record date, hardware setup, input conditions, expected result, actual result, pass/fail, and a photo or log if available.
